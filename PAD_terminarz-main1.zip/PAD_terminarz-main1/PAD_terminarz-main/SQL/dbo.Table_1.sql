﻿CREATE TABLE [dbo].[Terminarz]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Temat] NCHAR(30) NULL, 
    [Opis] NCHAR(180) NULL, 
    [Data] DATE NULL
)
