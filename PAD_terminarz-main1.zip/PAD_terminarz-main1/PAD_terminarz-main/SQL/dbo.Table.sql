﻿CREATE TABLE [dbo].[Terminarz]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Data] DATE NULL
)
