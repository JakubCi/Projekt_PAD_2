﻿namespace Projekt_PAD_1
{
    partial class zmienHaslo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(zmienHaslo));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ZHpowHaslo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnZmienHaslo = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Lpokazhaslo = new System.Windows.Forms.CheckBox();
            this.ZHhaslo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(8, 86);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 18);
            this.label1.TabIndex = 40;
            this.label1.Text = "Powtórz Hasło:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.ForeColor = System.Drawing.Color.Gray;
            this.panel1.Location = new System.Drawing.Point(12, 109);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(39, 36);
            this.panel1.TabIndex = 39;
            // 
            // ZHpowHaslo
            // 
            this.ZHpowHaslo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ZHpowHaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ZHpowHaslo.ForeColor = System.Drawing.Color.Gray;
            this.ZHpowHaslo.Location = new System.Drawing.Point(52, 109);
            this.ZHpowHaslo.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.ZHpowHaslo.Multiline = true;
            this.ZHpowHaslo.Name = "ZHpowHaslo";
            this.ZHpowHaslo.PasswordChar = '*';
            this.ZHpowHaslo.Size = new System.Drawing.Size(374, 37);
            this.ZHpowHaslo.TabIndex = 38;
            this.ZHpowHaslo.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(7, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 18);
            this.label3.TabIndex = 37;
            this.label3.Text = "Nowe Hasło:";
            // 
            // btnZmienHaslo
            // 
            this.btnZmienHaslo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(132)))), ((int)(((byte)(31)))));
            this.btnZmienHaslo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnZmienHaslo.FlatAppearance.BorderSize = 0;
            this.btnZmienHaslo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnZmienHaslo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnZmienHaslo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZmienHaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZmienHaslo.Location = new System.Drawing.Point(52, 271);
            this.btnZmienHaslo.Margin = new System.Windows.Forms.Padding(4);
            this.btnZmienHaslo.Name = "btnZmienHaslo";
            this.btnZmienHaslo.Size = new System.Drawing.Size(325, 47);
            this.btnZmienHaslo.TabIndex = 36;
            this.btnZmienHaslo.Text = "Zmień hasło";
            this.btnZmienHaslo.UseVisualStyleBackColor = false;
            this.btnZmienHaslo.Click += new System.EventHandler(this.btnZmienHaslo_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.ForeColor = System.Drawing.Color.Gray;
            this.panel3.Location = new System.Drawing.Point(11, 33);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 0, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(39, 36);
            this.panel3.TabIndex = 35;
            // 
            // Lpokazhaslo
            // 
            this.Lpokazhaslo.AutoSize = true;
            this.Lpokazhaslo.Checked = true;
            this.Lpokazhaslo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Lpokazhaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lpokazhaslo.ForeColor = System.Drawing.Color.Gray;
            this.Lpokazhaslo.Location = new System.Drawing.Point(10, 171);
            this.Lpokazhaslo.Margin = new System.Windows.Forms.Padding(4);
            this.Lpokazhaslo.Name = "Lpokazhaslo";
            this.Lpokazhaslo.Size = new System.Drawing.Size(141, 29);
            this.Lpokazhaslo.TabIndex = 34;
            this.Lpokazhaslo.Text = "Pokaż hasło";
            this.Lpokazhaslo.UseVisualStyleBackColor = true;
            this.Lpokazhaslo.CheckedChanged += new System.EventHandler(this.Lpokazhaslo_CheckedChanged);
            // 
            // ZHhaslo
            // 
            this.ZHhaslo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ZHhaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ZHhaslo.ForeColor = System.Drawing.Color.Gray;
            this.ZHhaslo.Location = new System.Drawing.Point(51, 33);
            this.ZHhaslo.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.ZHhaslo.Multiline = true;
            this.ZHhaslo.Name = "ZHhaslo";
            this.ZHhaslo.PasswordChar = '*';
            this.ZHhaslo.Size = new System.Drawing.Size(374, 37);
            this.ZHhaslo.TabIndex = 33;
            this.ZHhaslo.UseSystemPasswordChar = true;
            // 
            // zmienHaslo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 347);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ZHpowHaslo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnZmienHaslo);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Lpokazhaslo);
            this.Controls.Add(this.ZHhaslo);
            this.Name = "zmienHaslo";
            this.Text = "Zmień Hasło";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.TextBox ZHpowHaslo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnZmienHaslo;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox Lpokazhaslo;
        public System.Windows.Forms.TextBox ZHhaslo;
    }
}