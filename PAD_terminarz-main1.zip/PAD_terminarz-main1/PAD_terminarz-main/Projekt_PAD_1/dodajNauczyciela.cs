﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt_PAD_1
{
    public partial class dodajNauczyciela : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Szkola.mdf;Integrated Security=True;Connect Timeout=30");

        public dodajNauczyciela()
        {
            InitializeComponent();
        }
        public dodajNauczyciela(adminNauczyciele aU)
        {
            conn.Open();
            InitializeComponent();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT Id,NazwaKlasy FROM Klasy WHERE NazwaKlasy !='Brak Wych.'", conn);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "NazwaKlasy";
            comboBox1.ValueMember = "Id";
            conn.Close();

            _aU = aU;
        }
        adminNauczyciele _aU = new adminNauczyciele();
        private void btnUtworz_Click(object sender, EventArgs e)
        {
            conn.Open();/*
            SqlCommand cmd = new SqlCommand("INSERT INTO Uczniowie(Imie,Nazwisko,Pesel,Id_Klasa) values('" + dodajuczniaImie.Text + "','" + dodajuczniaNazwisko.Text + "','" + dodajuczniaPesel.Text + "','" + comboBox1.SelectedIndex.ToString() + "')", conn);
            cmd.ExecuteNonQuery();*/

            SqlDataAdapter adapter2 = new SqlDataAdapter("SELECT Uczniowie.Imie,Uczniowie.Nazwisko,Uczniowie.Pesel,Klasy.NazwaKlasy FROM Uczniowie,Klasy WHERE Uczniowie.Id_Klasa = Klasy.Id ORDER BY Klasy.NazwaKlasy", conn);
            DataTable dt2 = new DataTable();
            adapter2.Fill(dt2);
            conn.Close();
            this.Close();
        }

        private void btnCofnij_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
