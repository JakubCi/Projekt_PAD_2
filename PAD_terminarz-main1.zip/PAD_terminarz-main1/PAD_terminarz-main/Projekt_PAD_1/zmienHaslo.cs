﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt_PAD_1
{
    public partial class zmienHaslo : Form
    {
        public zmienHaslo()
        {
            InitializeComponent();
        }

        private void btnZmienHaslo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Pomyślnie zmieniono hasło. Możesz się teraz zalogować.", "Zmiana hasła", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void Lpokazhaslo_CheckedChanged(object sender, EventArgs e)
        {

            if (Lpokazhaslo.Checked == true)
            {
                ZHhaslo.UseSystemPasswordChar = true;
                ZHpowHaslo.UseSystemPasswordChar = true;
            }
            else if (Lpokazhaslo.Checked == false)
            {
                ZHhaslo.UseSystemPasswordChar = false;
                ZHpowHaslo.UseSystemPasswordChar = false;
            }
        }
    }
}
