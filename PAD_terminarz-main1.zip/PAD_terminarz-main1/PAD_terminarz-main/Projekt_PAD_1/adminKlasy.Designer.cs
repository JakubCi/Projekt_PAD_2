﻿namespace Projekt_PAD_1
{
    partial class adminKlasy
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnDodajklase;
            System.Windows.Forms.Button btnEdytujklase;
            System.Windows.Forms.Button btnUsunklase;
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Lpanel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            btnDodajklase = new System.Windows.Forms.Button();
            btnEdytujklase = new System.Windows.Forms.Button();
            btnUsunklase = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDodajklase
            // 
            btnDodajklase.BackColor = System.Drawing.Color.Transparent;
            btnDodajklase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnDodajklase.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnDodajklase.FlatAppearance.BorderSize = 0;
            btnDodajklase.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnDodajklase.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnDodajklase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDodajklase.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnDodajklase.Location = new System.Drawing.Point(60, 386);
            btnDodajklase.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            btnDodajklase.Name = "btnDodajklase";
            btnDodajklase.Size = new System.Drawing.Size(136, 47);
            btnDodajklase.TabIndex = 28;
            btnDodajklase.Text = "Dodaj";
            btnDodajklase.UseVisualStyleBackColor = false;
            btnDodajklase.Click += new System.EventHandler(this.btnDodajklase_Click);
            // 
            // btnEdytujklase
            // 
            btnEdytujklase.BackColor = System.Drawing.Color.Transparent;
            btnEdytujklase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnEdytujklase.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnEdytujklase.FlatAppearance.BorderSize = 0;
            btnEdytujklase.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnEdytujklase.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnEdytujklase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnEdytujklase.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnEdytujklase.Location = new System.Drawing.Point(267, 386);
            btnEdytujklase.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            btnEdytujklase.Name = "btnEdytujklase";
            btnEdytujklase.Size = new System.Drawing.Size(136, 47);
            btnEdytujklase.TabIndex = 30;
            btnEdytujklase.Text = "Edytuj";
            btnEdytujklase.UseVisualStyleBackColor = false;
            // 
            // btnUsunklase
            // 
            btnUsunklase.BackColor = System.Drawing.Color.Transparent;
            btnUsunklase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnUsunklase.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnUsunklase.FlatAppearance.BorderSize = 0;
            btnUsunklase.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnUsunklase.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnUsunklase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnUsunklase.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnUsunklase.Location = new System.Drawing.Point(467, 386);
            btnUsunklase.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            btnUsunklase.Name = "btnUsunklase";
            btnUsunklase.Size = new System.Drawing.Size(136, 47);
            btnUsunklase.TabIndex = 32;
            btnUsunklase.Text = "Usuń";
            btnUsunklase.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 2);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(656, 363);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Lpanel2
            // 
            this.Lpanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Lpanel2.Location = new System.Drawing.Point(60, 428);
            this.Lpanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Lpanel2.Name = "Lpanel2";
            this.Lpanel2.Size = new System.Drawing.Size(136, 6);
            this.Lpanel2.TabIndex = 29;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.panel1.Location = new System.Drawing.Point(267, 427);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(136, 6);
            this.panel1.TabIndex = 31;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.panel2.Location = new System.Drawing.Point(467, 427);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(136, 6);
            this.panel2.TabIndex = 33;
            // 
            // adminKlasy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(btnUsunklase);
            this.Controls.Add(this.panel1);
            this.Controls.Add(btnEdytujklase);
            this.Controls.Add(this.Lpanel2);
            this.Controls.Add(btnDodajklase);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "adminKlasy";
            this.Size = new System.Drawing.Size(661, 447);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel Lpanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}
