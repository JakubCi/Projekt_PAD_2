﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Projekt_PAD_1
{
    public partial class nauczycielMain : Form
    {

        public nauczycielMain()
        {
            InitializeComponent();
        }

        private void btnKlasy_Click(object sender, EventArgs e)
        {
            Apanel1.Visible = false;
            Apanel2.Visible = false;
            Apanel3.Visible = true;
            nauczycielKlasy nauczycielKlasy = new nauczycielKlasy();
            panel4.Controls.Add(nauczycielKlasy);
            nauczycielKlasy.Visible = true;
            nauczycielKlasy.Dock = DockStyle.Fill;
            nauczycielKlasy.BringToFront();
        }

        private void btnPlanLekcji_Click(object sender, EventArgs e)
        {
            Apanel1.Visible = false;
            Apanel2.Visible = true;
            Apanel3.Visible = false;
            nauczycielPlanLekcji nauczycielPlanLekcji = new nauczycielPlanLekcji();
            panel4.Controls.Add(nauczycielPlanLekcji);
            nauczycielPlanLekcji.Visible = true;
            nauczycielPlanLekcji.Dock = DockStyle.Fill;
            nauczycielPlanLekcji.BringToFront();
        }

        private void btnTerminarz_Click(object sender, EventArgs e)
        {
            Apanel1.Visible = true;
            Apanel2.Visible = false;
            Apanel3.Visible = false;
            nauczycielTerminarzWaga nauczycielTerminarz = new nauczycielTerminarzWaga();
            panel4.Controls.Add(nauczycielTerminarz);
            nauczycielTerminarz.Visible = true;
            nauczycielTerminarz.Dock = DockStyle.Fill;
            nauczycielTerminarz.BringToFront();
        }

        private void btnWyloguj_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Czy napewno chcesz się wylogować?", "Wyloguj się", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                this.Hide();
                LogowanieiRejstracja logowanieiRejstracja = new LogowanieiRejstracja();
                logowanieiRejstracja.Show();
            }
        }

        private void nauczycielMain_Load(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void spinningCircles1_Click(object sender, EventArgs e)
        {

        }
    }
}
