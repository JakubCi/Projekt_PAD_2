﻿namespace Projekt_PAD_1
{
    partial class dodajNauczyciela
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnCofnij = new System.Windows.Forms.Button();
            this.btnUtworz = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dodajnauczycielaPrzedmiot = new System.Windows.Forms.TextBox();
            this.dodajnauczycielaNazwisko = new System.Windows.Forms.TextBox();
            this.dodajnauczycielaImie = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(13, 285);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(372, 24);
            this.comboBox1.TabIndex = 36;
            // 
            // btnCofnij
            // 
            this.btnCofnij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(132)))), ((int)(((byte)(31)))));
            this.btnCofnij.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCofnij.FlatAppearance.BorderSize = 0;
            this.btnCofnij.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCofnij.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnCofnij.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCofnij.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCofnij.Location = new System.Drawing.Point(13, 391);
            this.btnCofnij.Margin = new System.Windows.Forms.Padding(4);
            this.btnCofnij.Name = "btnCofnij";
            this.btnCofnij.Size = new System.Drawing.Size(187, 47);
            this.btnCofnij.TabIndex = 35;
            this.btnCofnij.Text = "Cofnij";
            this.btnCofnij.UseVisualStyleBackColor = false;
            this.btnCofnij.Click += new System.EventHandler(this.btnCofnij_Click);
            // 
            // btnUtworz
            // 
            this.btnUtworz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(132)))), ((int)(((byte)(31)))));
            this.btnUtworz.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnUtworz.FlatAppearance.BorderSize = 0;
            this.btnUtworz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUtworz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnUtworz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUtworz.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUtworz.Location = new System.Drawing.Point(219, 391);
            this.btnUtworz.Margin = new System.Windows.Forms.Padding(4);
            this.btnUtworz.Name = "btnUtworz";
            this.btnUtworz.Size = new System.Drawing.Size(187, 47);
            this.btnUtworz.TabIndex = 34;
            this.btnUtworz.Text = "Utwórz";
            this.btnUtworz.UseVisualStyleBackColor = false;
            this.btnUtworz.Click += new System.EventHandler(this.btnUtworz_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 262);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 21);
            this.label4.TabIndex = 33;
            this.label4.Text = "Klasa";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 21);
            this.label3.TabIndex = 32;
            this.label3.Text = "Przedmiot";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 21);
            this.label2.TabIndex = 31;
            this.label2.Text = "Nazwisko";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 21);
            this.label1.TabIndex = 30;
            this.label1.Text = "Imię";
            // 
            // dodajnauczycielaPrzedmiot
            // 
            this.dodajnauczycielaPrzedmiot.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dodajnauczycielaPrzedmiot.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dodajnauczycielaPrzedmiot.ForeColor = System.Drawing.Color.Gray;
            this.dodajnauczycielaPrzedmiot.Location = new System.Drawing.Point(13, 210);
            this.dodajnauczycielaPrzedmiot.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.dodajnauczycielaPrzedmiot.Multiline = true;
            this.dodajnauczycielaPrzedmiot.Name = "dodajnauczycielaPrzedmiot";
            this.dodajnauczycielaPrzedmiot.Size = new System.Drawing.Size(373, 37);
            this.dodajnauczycielaPrzedmiot.TabIndex = 29;
            // 
            // dodajnauczycielaNazwisko
            // 
            this.dodajnauczycielaNazwisko.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dodajnauczycielaNazwisko.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dodajnauczycielaNazwisko.ForeColor = System.Drawing.Color.Gray;
            this.dodajnauczycielaNazwisko.Location = new System.Drawing.Point(13, 127);
            this.dodajnauczycielaNazwisko.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.dodajnauczycielaNazwisko.Multiline = true;
            this.dodajnauczycielaNazwisko.Name = "dodajnauczycielaNazwisko";
            this.dodajnauczycielaNazwisko.PasswordChar = '*';
            this.dodajnauczycielaNazwisko.Size = new System.Drawing.Size(373, 37);
            this.dodajnauczycielaNazwisko.TabIndex = 28;
            this.dodajnauczycielaNazwisko.UseSystemPasswordChar = true;
            // 
            // dodajnauczycielaImie
            // 
            this.dodajnauczycielaImie.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dodajnauczycielaImie.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dodajnauczycielaImie.ForeColor = System.Drawing.Color.Gray;
            this.dodajnauczycielaImie.Location = new System.Drawing.Point(13, 50);
            this.dodajnauczycielaImie.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.dodajnauczycielaImie.Multiline = true;
            this.dodajnauczycielaImie.Name = "dodajnauczycielaImie";
            this.dodajnauczycielaImie.Size = new System.Drawing.Size(373, 37);
            this.dodajnauczycielaImie.TabIndex = 27;
            // 
            // dodajNauczyciela
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 462);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnCofnij);
            this.Controls.Add(this.btnUtworz);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dodajnauczycielaPrzedmiot);
            this.Controls.Add(this.dodajnauczycielaNazwisko);
            this.Controls.Add(this.dodajnauczycielaImie);
            this.Name = "dodajNauczyciela";
            this.Text = "dodajNauczyciela";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnCofnij;
        private System.Windows.Forms.Button btnUtworz;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox dodajnauczycielaPrzedmiot;
        public System.Windows.Forms.TextBox dodajnauczycielaNazwisko;
        public System.Windows.Forms.TextBox dodajnauczycielaImie;
    }
}