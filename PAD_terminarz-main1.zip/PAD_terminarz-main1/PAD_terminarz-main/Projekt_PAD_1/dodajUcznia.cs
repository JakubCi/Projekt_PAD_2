﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Projekt_PAD_1
{
    public partial class dodajUcznia : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Szkola.mdf;Integrated Security=True;Connect Timeout=30");

        public dodajUcznia()
        {

            InitializeComponent();
        }

        public dodajUcznia(adminUczniowie aU)
        {
            conn.Open();
            InitializeComponent();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT Id,NazwaKlasy FROM Klasy WHERE NazwaKlasy !='Brak Wych.'", conn);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "NazwaKlasy";
            comboBox1.ValueMember = "Id";
            conn.Close();

            _aU = aU;
        }
        adminUczniowie _aU = new adminUczniowie();

        private void btnCofnij_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void btnUtworz_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Uczniowie(Imie,Nazwisko,Pesel,Id_Klasa) values('" + dodajuczniaImie.Text + "','" + dodajuczniaNazwisko.Text + "','" + dodajuczniaPesel.Text + "','" + comboBox1.SelectedIndex.ToString() + "')", conn);
            cmd.ExecuteNonQuery();

            SqlDataAdapter adapter2 = new SqlDataAdapter("SELECT Uczniowie.Imie,Uczniowie.Nazwisko,Uczniowie.Pesel,Klasy.NazwaKlasy FROM Uczniowie,Klasy WHERE Uczniowie.Id_Klasa = Klasy.Id ORDER BY Klasy.NazwaKlasy", conn);
            DataTable dt2 = new DataTable();
            adapter2.Fill(dt2);
            _aU.dataGridView1.DataSource = dt2;
            conn.Close();
            this.Close();
        }

        private void dodajuczniaImie_TextChanged(object sender, EventArgs e)
        {

        }

        private void dodajuczniaNazwisko_TextChanged(object sender, EventArgs e)
        {

        }

        private void dodajuczniaPesel_TextChanged(object sender, EventArgs e)
        {

        }

        private void dodajuczniaKlasa_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
