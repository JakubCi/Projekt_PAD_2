﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Projekt_PAD_1
{
    public partial class adminNauczyciele : UserControl
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Szkola.mdf;Integrated Security=True;Connect Timeout=30");

        public adminNauczyciele()
        {
            conn.Open();
            InitializeComponent();
            SqlDataAdapter adapter2 = new SqlDataAdapter("SELECT Nauczyciele.Imie,Nauczyciele.Nazwisko,Nauczyciele.Przedmiot,Klasy.NazwaKlasy FROM Nauczyciele,Klasy WHERE Nauczyciele.Id_KlasyWychowawca = Klasy.Id_Wychowawca", conn);
            DataTable dt2 = new DataTable();
            adapter2.Fill(dt2);
            dataGridView1.DataSource = dt2;
            conn.Close();


            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249);
            dataGridView1.BackgroundColor = Color.FromArgb(30, 30, 30); ;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.SeaGreen;
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.WhiteSmoke;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("MS Reference Sans Serif", 10);
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(37, 37, 38);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns[2].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnDodajnauczyciela_Click(object sender, EventArgs e)
        {
            dodajNauczyciela dodajNauczyciela = new dodajNauczyciela(this);
            dodajNauczyciela.Show();
        }
    }
}
