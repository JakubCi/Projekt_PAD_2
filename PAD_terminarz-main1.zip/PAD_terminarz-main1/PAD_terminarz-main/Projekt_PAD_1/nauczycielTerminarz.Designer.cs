﻿namespace Projekt_PAD_1
{
    partial class nauczycielTerminarzWaga
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nauczycielTerminarzTemat = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Apanel3 = new System.Windows.Forms.Panel();
            this.btnZatwierdź = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Data = new System.Windows.Forms.DateTimePicker();
            this.szkolaDataSet = new Projekt_PAD_1.SzkolaDataSet();
            this.szkolaDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szkolaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szkolaDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // nauczycielTerminarzTemat
            // 
            this.nauczycielTerminarzTemat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nauczycielTerminarzTemat.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nauczycielTerminarzTemat.ForeColor = System.Drawing.Color.Gray;
            this.nauczycielTerminarzTemat.Location = new System.Drawing.Point(23, 36);
            this.nauczycielTerminarzTemat.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.nauczycielTerminarzTemat.Multiline = true;
            this.nauczycielTerminarzTemat.Name = "nauczycielTerminarzTemat";
            this.nauczycielTerminarzTemat.Size = new System.Drawing.Size(265, 37);
            this.nauczycielTerminarzTemat.TabIndex = 23;
            this.nauczycielTerminarzTemat.TextChanged += new System.EventHandler(this.nauczycielTerminarzTemat_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 24);
            this.label1.TabIndex = 24;
            this.label1.Text = "Temat:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 177);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(656, 267);
            this.dataGridView1.TabIndex = 25;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Apanel3
            // 
            this.Apanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Apanel3.Location = new System.Drawing.Point(355, 139);
            this.Apanel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Apanel3.Name = "Apanel3";
            this.Apanel3.Size = new System.Drawing.Size(267, 7);
            this.Apanel3.TabIndex = 33;
            this.Apanel3.Visible = false;
            // 
            // btnZatwierdź
            // 
            this.btnZatwierdź.BackColor = System.Drawing.Color.Transparent;
            this.btnZatwierdź.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnZatwierdź.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnZatwierdź.FlatAppearance.BorderSize = 0;
            this.btnZatwierdź.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnZatwierdź.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnZatwierdź.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZatwierdź.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZatwierdź.Location = new System.Drawing.Point(355, 110);
            this.btnZatwierdź.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnZatwierdź.Name = "btnZatwierdź";
            this.btnZatwierdź.Size = new System.Drawing.Size(267, 37);
            this.btnZatwierdź.TabIndex = 32;
            this.btnZatwierdź.Text = "Zatwierdź";
            this.btnZatwierdź.UseVisualStyleBackColor = false;
            this.btnZatwierdź.Click += new System.EventHandler(this.btnZatwierdź_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 24);
            this.label2.TabIndex = 35;
            this.label2.Text = "Waga:";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.ForeColor = System.Drawing.Color.Gray;
            this.textBox1.Location = new System.Drawing.Point(23, 110);
            this.textBox1.Margin = new System.Windows.Forms.Padding(0, 4, 4, 4);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(265, 37);
            this.textBox1.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(351, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 24);
            this.label3.TabIndex = 37;
            this.label3.Text = "DD-MM-YY:";
            // 
            // Data
            // 
            this.Data.CustomFormat = "dd MMMM yyyy";
            this.Data.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Data.Location = new System.Drawing.Point(355, 36);
            this.Data.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(265, 22);
            this.Data.TabIndex = 38;
            // 
            // szkolaDataSet
            // 
            this.szkolaDataSet.DataSetName = "SzkolaDataSet";
            this.szkolaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // szkolaDataSetBindingSource
            // 
            this.szkolaDataSetBindingSource.AllowNew = true;
            this.szkolaDataSetBindingSource.DataSource = this.szkolaDataSet;
            this.szkolaDataSetBindingSource.Position = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(356, 80);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(264, 24);
            this.comboBox1.TabIndex = 39;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // nauczycielTerminarzWaga
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Apanel3);
            this.Controls.Add(this.btnZatwierdź);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nauczycielTerminarzTemat);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "nauczycielTerminarzWaga";
            this.Size = new System.Drawing.Size(661, 447);
            this.Load += new System.EventHandler(this.nauczycielTerminarzWaga_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szkolaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szkolaDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox nauczycielTerminarzTemat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel Apanel3;
        private System.Windows.Forms.Button btnZatwierdź;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker Data;
        private SzkolaDataSet szkolaDataSet;
        private System.Windows.Forms.BindingSource szkolaDataSetBindingSource;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}
