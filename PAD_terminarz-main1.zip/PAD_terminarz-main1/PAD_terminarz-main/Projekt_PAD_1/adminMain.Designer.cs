﻿namespace Projekt_PAD_1
{
    partial class adminMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnKlasy;
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Apanel3 = new System.Windows.Forms.Panel();
            this.btnWyloguj = new System.Windows.Forms.Button();
            this.btnUczniowie = new System.Windows.Forms.Button();
            this.Apanel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Apanel2 = new System.Windows.Forms.Panel();
            this.btnNauczyciele = new System.Windows.Forms.Button();
            btnKlasy = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Apanel2);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.btnNauczyciele);
            this.panel1.Controls.Add(this.Apanel3);
            this.panel1.Controls.Add(this.btnWyloguj);
            this.panel1.Controls.Add(this.btnUczniowie);
            this.panel1.Controls.Add(this.Apanel1);
            this.panel1.Controls.Add(btnKlasy);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(662, 79);
            this.panel1.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(122)))), ((int)(((byte)(30)))));
            this.panel5.Location = new System.Drawing.Point(497, 53);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(154, 6);
            this.panel5.TabIndex = 33;
            // 
            // Apanel3
            // 
            this.Apanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Apanel3.Location = new System.Drawing.Point(335, 53);
            this.Apanel3.Margin = new System.Windows.Forms.Padding(4);
            this.Apanel3.Name = "Apanel3";
            this.Apanel3.Size = new System.Drawing.Size(154, 6);
            this.Apanel3.TabIndex = 31;
            this.Apanel3.Visible = false;
            // 
            // btnWyloguj
            // 
            this.btnWyloguj.BackColor = System.Drawing.Color.Transparent;
            this.btnWyloguj.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnWyloguj.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnWyloguj.FlatAppearance.BorderSize = 0;
            this.btnWyloguj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnWyloguj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnWyloguj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWyloguj.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWyloguj.Location = new System.Drawing.Point(497, 13);
            this.btnWyloguj.Margin = new System.Windows.Forms.Padding(4);
            this.btnWyloguj.Name = "btnWyloguj";
            this.btnWyloguj.Size = new System.Drawing.Size(154, 47);
            this.btnWyloguj.TabIndex = 32;
            this.btnWyloguj.Text = "Wyloguj się";
            this.btnWyloguj.UseVisualStyleBackColor = false;
            this.btnWyloguj.Click += new System.EventHandler(this.btnWyloguj_Click);
            // 
            // btnUczniowie
            // 
            this.btnUczniowie.BackColor = System.Drawing.Color.Transparent;
            this.btnUczniowie.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnUczniowie.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnUczniowie.FlatAppearance.BorderSize = 0;
            this.btnUczniowie.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUczniowie.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnUczniowie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUczniowie.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUczniowie.Location = new System.Drawing.Point(335, 13);
            this.btnUczniowie.Margin = new System.Windows.Forms.Padding(4);
            this.btnUczniowie.Name = "btnUczniowie";
            this.btnUczniowie.Size = new System.Drawing.Size(154, 47);
            this.btnUczniowie.TabIndex = 30;
            this.btnUczniowie.Text = "Uczniowie";
            this.btnUczniowie.UseVisualStyleBackColor = false;
            this.btnUczniowie.Click += new System.EventHandler(this.btnUczniowie_Click);
            // 
            // Apanel1
            // 
            this.Apanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Apanel1.Location = new System.Drawing.Point(11, 53);
            this.Apanel1.Margin = new System.Windows.Forms.Padding(4);
            this.Apanel1.Name = "Apanel1";
            this.Apanel1.Size = new System.Drawing.Size(154, 6);
            this.Apanel1.TabIndex = 27;
            this.Apanel1.Visible = false;
            // 
            // btnKlasy
            // 
            btnKlasy.BackColor = System.Drawing.Color.Transparent;
            btnKlasy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnKlasy.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnKlasy.FlatAppearance.BorderSize = 0;
            btnKlasy.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnKlasy.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnKlasy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnKlasy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnKlasy.Location = new System.Drawing.Point(11, 13);
            btnKlasy.Margin = new System.Windows.Forms.Padding(4);
            btnKlasy.Name = "btnKlasy";
            btnKlasy.Size = new System.Drawing.Size(154, 47);
            btnKlasy.TabIndex = 26;
            btnKlasy.Text = "Klasy";
            btnKlasy.UseVisualStyleBackColor = false;
            btnKlasy.Click += new System.EventHandler(this.btnKlasy_Click);
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 85);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(662, 447);
            this.panel4.TabIndex = 2;
            // 
            // Apanel2
            // 
            this.Apanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Apanel2.Location = new System.Drawing.Point(173, 53);
            this.Apanel2.Margin = new System.Windows.Forms.Padding(4);
            this.Apanel2.Name = "Apanel2";
            this.Apanel2.Size = new System.Drawing.Size(154, 6);
            this.Apanel2.TabIndex = 33;
            this.Apanel2.Visible = false;
            // 
            // btnNauczyciele
            // 
            this.btnNauczyciele.BackColor = System.Drawing.Color.Transparent;
            this.btnNauczyciele.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNauczyciele.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnNauczyciele.FlatAppearance.BorderSize = 0;
            this.btnNauczyciele.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnNauczyciele.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnNauczyciele.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNauczyciele.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNauczyciele.Location = new System.Drawing.Point(173, 13);
            this.btnNauczyciele.Margin = new System.Windows.Forms.Padding(4);
            this.btnNauczyciele.Name = "btnNauczyciele";
            this.btnNauczyciele.Size = new System.Drawing.Size(154, 47);
            this.btnNauczyciele.TabIndex = 32;
            this.btnNauczyciele.Text = "Nauczyciele";
            this.btnNauczyciele.UseVisualStyleBackColor = false;
            this.btnNauczyciele.Click += new System.EventHandler(this.btnNauczyciele_Click);
            // 
            // adminMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 532);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "adminMain";
            this.Text = "adminMain";
            this.Load += new System.EventHandler(this.adminMain_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel Apanel3;
        private System.Windows.Forms.Button btnWyloguj;
        private System.Windows.Forms.Button btnUczniowie;
        private System.Windows.Forms.Panel Apanel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel Apanel2;
        private System.Windows.Forms.Button btnNauczyciele;
    }
}