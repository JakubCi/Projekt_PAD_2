﻿namespace Projekt_PAD_1
{
    partial class adminNauczyciele
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnUsunnauczyciela;
            System.Windows.Forms.Button btnEdytujnauczyciela;
            System.Windows.Forms.Button btnDodajnauczyciela;
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Lpanel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            btnUsunnauczyciela = new System.Windows.Forms.Button();
            btnEdytujnauczyciela = new System.Windows.Forms.Button();
            btnDodajnauczyciela = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUsunnauczyciela
            // 
            btnUsunnauczyciela.BackColor = System.Drawing.Color.Transparent;
            btnUsunnauczyciela.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnUsunnauczyciela.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnUsunnauczyciela.FlatAppearance.BorderSize = 0;
            btnUsunnauczyciela.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnUsunnauczyciela.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnUsunnauczyciela.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnUsunnauczyciela.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnUsunnauczyciela.Location = new System.Drawing.Point(467, 391);
            btnUsunnauczyciela.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            btnUsunnauczyciela.Name = "btnUsunnauczyciela";
            btnUsunnauczyciela.Size = new System.Drawing.Size(136, 47);
            btnUsunnauczyciela.TabIndex = 39;
            btnUsunnauczyciela.Text = "Usuń";
            btnUsunnauczyciela.UseVisualStyleBackColor = false;
            // 
            // btnEdytujnauczyciela
            // 
            btnEdytujnauczyciela.BackColor = System.Drawing.Color.Transparent;
            btnEdytujnauczyciela.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnEdytujnauczyciela.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnEdytujnauczyciela.FlatAppearance.BorderSize = 0;
            btnEdytujnauczyciela.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnEdytujnauczyciela.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnEdytujnauczyciela.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnEdytujnauczyciela.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnEdytujnauczyciela.Location = new System.Drawing.Point(267, 391);
            btnEdytujnauczyciela.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            btnEdytujnauczyciela.Name = "btnEdytujnauczyciela";
            btnEdytujnauczyciela.Size = new System.Drawing.Size(136, 47);
            btnEdytujnauczyciela.TabIndex = 37;
            btnEdytujnauczyciela.Text = "Edytuj";
            btnEdytujnauczyciela.UseVisualStyleBackColor = false;
            // 
            // btnDodajnauczyciela
            // 
            btnDodajnauczyciela.BackColor = System.Drawing.Color.Transparent;
            btnDodajnauczyciela.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnDodajnauczyciela.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnDodajnauczyciela.FlatAppearance.BorderSize = 0;
            btnDodajnauczyciela.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnDodajnauczyciela.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnDodajnauczyciela.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDodajnauczyciela.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnDodajnauczyciela.Location = new System.Drawing.Point(60, 391);
            btnDodajnauczyciela.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            btnDodajnauczyciela.Name = "btnDodajnauczyciela";
            btnDodajnauczyciela.Size = new System.Drawing.Size(136, 47);
            btnDodajnauczyciela.TabIndex = 35;
            btnDodajnauczyciela.Text = "Dodaj";
            btnDodajnauczyciela.UseVisualStyleBackColor = false;
            btnDodajnauczyciela.Click += new System.EventHandler(this.btnDodajnauczyciela_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.panel2.Location = new System.Drawing.Point(467, 432);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(136, 6);
            this.panel2.TabIndex = 40;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.panel1.Location = new System.Drawing.Point(267, 432);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(136, 6);
            this.panel1.TabIndex = 38;
            // 
            // Lpanel2
            // 
            this.Lpanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Lpanel2.Location = new System.Drawing.Point(60, 433);
            this.Lpanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Lpanel2.Name = "Lpanel2";
            this.Lpanel2.Size = new System.Drawing.Size(136, 6);
            this.Lpanel2.TabIndex = 36;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 7);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(656, 363);
            this.dataGridView1.TabIndex = 34;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // adminNauczyciele
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(btnUsunnauczyciela);
            this.Controls.Add(this.panel1);
            this.Controls.Add(btnEdytujnauczyciela);
            this.Controls.Add(this.Lpanel2);
            this.Controls.Add(btnDodajnauczyciela);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "adminNauczyciele";
            this.Size = new System.Drawing.Size(661, 447);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel Lpanel2;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}
