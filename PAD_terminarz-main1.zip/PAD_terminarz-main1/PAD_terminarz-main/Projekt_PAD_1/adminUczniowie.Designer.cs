﻿namespace Projekt_PAD_1
{
    partial class adminUczniowie
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnUsunucznia;
            System.Windows.Forms.Button btnEdytujucznia;
            System.Windows.Forms.Button btnDodaucznia;
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Lpanel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            btnUsunucznia = new System.Windows.Forms.Button();
            btnEdytujucznia = new System.Windows.Forms.Button();
            btnDodaucznia = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUsunucznia
            // 
            btnUsunucznia.BackColor = System.Drawing.Color.Transparent;
            btnUsunucznia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnUsunucznia.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnUsunucznia.FlatAppearance.BorderSize = 0;
            btnUsunucznia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnUsunucznia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnUsunucznia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnUsunucznia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnUsunucznia.Location = new System.Drawing.Point(350, 318);
            btnUsunucznia.Name = "btnUsunucznia";
            btnUsunucznia.Size = new System.Drawing.Size(102, 38);
            btnUsunucznia.TabIndex = 39;
            btnUsunucznia.Text = "Usuń";
            btnUsunucznia.UseVisualStyleBackColor = false;
            // 
            // btnEdytujucznia
            // 
            btnEdytujucznia.BackColor = System.Drawing.Color.Transparent;
            btnEdytujucznia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnEdytujucznia.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnEdytujucznia.FlatAppearance.BorderSize = 0;
            btnEdytujucznia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnEdytujucznia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnEdytujucznia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnEdytujucznia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnEdytujucznia.Location = new System.Drawing.Point(200, 318);
            btnEdytujucznia.Name = "btnEdytujucznia";
            btnEdytujucznia.Size = new System.Drawing.Size(102, 38);
            btnEdytujucznia.TabIndex = 37;
            btnEdytujucznia.Text = "Edytuj";
            btnEdytujucznia.UseVisualStyleBackColor = false;
            btnEdytujucznia.Click += new System.EventHandler(this.btnEdytujucznia_Click);
            // 
            // btnDodaucznia
            // 
            btnDodaucznia.BackColor = System.Drawing.Color.Transparent;
            btnDodaucznia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnDodaucznia.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnDodaucznia.FlatAppearance.BorderSize = 0;
            btnDodaucznia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnDodaucznia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnDodaucznia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDodaucznia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnDodaucznia.Location = new System.Drawing.Point(45, 318);
            btnDodaucznia.Name = "btnDodaucznia";
            btnDodaucznia.Size = new System.Drawing.Size(102, 38);
            btnDodaucznia.TabIndex = 35;
            btnDodaucznia.Text = "Dodaj";
            btnDodaucznia.UseVisualStyleBackColor = false;
            btnDodaucznia.Click += new System.EventHandler(this.btnDodaucznia_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.panel2.Location = new System.Drawing.Point(350, 351);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(102, 5);
            this.panel2.TabIndex = 40;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.panel1.Location = new System.Drawing.Point(200, 351);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(102, 5);
            this.panel1.TabIndex = 38;
            // 
            // Lpanel2
            // 
            this.Lpanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Lpanel2.Location = new System.Drawing.Point(45, 352);
            this.Lpanel2.Name = "Lpanel2";
            this.Lpanel2.Size = new System.Drawing.Size(102, 5);
            this.Lpanel2.TabIndex = 36;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(2, 6);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(492, 295);
            this.dataGridView1.TabIndex = 34;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // adminUczniowie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(btnUsunucznia);
            this.Controls.Add(this.panel1);
            this.Controls.Add(btnEdytujucznia);
            this.Controls.Add(this.Lpanel2);
            this.Controls.Add(btnDodaucznia);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "adminUczniowie";
            this.Size = new System.Drawing.Size(496, 363);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel Lpanel2;
        public System.Windows.Forms.DataGridView dataGridView1;
    }
}
