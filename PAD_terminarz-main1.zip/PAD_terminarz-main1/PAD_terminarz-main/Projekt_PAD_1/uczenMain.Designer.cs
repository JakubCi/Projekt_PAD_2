﻿namespace Projekt_PAD_1
{
    partial class uczenMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnTerminarz;
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnWyloguj = new System.Windows.Forms.Button();
            this.Apanel2 = new System.Windows.Forms.Panel();
            this.btnPlanlekcji = new System.Windows.Forms.Button();
            this.Apanel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            btnTerminarz = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTerminarz
            // 
            btnTerminarz.BackColor = System.Drawing.Color.Transparent;
            btnTerminarz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            btnTerminarz.FlatAppearance.BorderColor = System.Drawing.Color.White;
            btnTerminarz.FlatAppearance.BorderSize = 0;
            btnTerminarz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            btnTerminarz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            btnTerminarz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnTerminarz.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnTerminarz.Location = new System.Drawing.Point(37, 11);
            btnTerminarz.Name = "btnTerminarz";
            btnTerminarz.Size = new System.Drawing.Size(102, 38);
            btnTerminarz.TabIndex = 26;
            btnTerminarz.Text = "Terminarz";
            btnTerminarz.UseVisualStyleBackColor = false;
            btnTerminarz.Click += new System.EventHandler(this.btnTerminarz_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.btnWyloguj);
            this.panel1.Controls.Add(this.Apanel2);
            this.panel1.Controls.Add(this.btnPlanlekcji);
            this.panel1.Controls.Add(this.Apanel1);
            this.panel1.Controls.Add(btnTerminarz);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(459, 64);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(122)))), ((int)(((byte)(30)))));
            this.panel5.Location = new System.Drawing.Point(317, 45);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(102, 5);
            this.panel5.TabIndex = 33;
            this.panel5.Visible = false;
            // 
            // btnWyloguj
            // 
            this.btnWyloguj.BackColor = System.Drawing.Color.Transparent;
            this.btnWyloguj.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnWyloguj.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnWyloguj.FlatAppearance.BorderSize = 0;
            this.btnWyloguj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnWyloguj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnWyloguj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWyloguj.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWyloguj.Location = new System.Drawing.Point(317, 12);
            this.btnWyloguj.Name = "btnWyloguj";
            this.btnWyloguj.Size = new System.Drawing.Size(102, 38);
            this.btnWyloguj.TabIndex = 32;
            this.btnWyloguj.Text = "Wyloguj się";
            this.btnWyloguj.UseVisualStyleBackColor = false;
            this.btnWyloguj.Click += new System.EventHandler(this.btnWyloguj_Click);
            // 
            // Apanel2
            // 
            this.Apanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Apanel2.Location = new System.Drawing.Point(176, 44);
            this.Apanel2.Name = "Apanel2";
            this.Apanel2.Size = new System.Drawing.Size(102, 5);
            this.Apanel2.TabIndex = 29;
            this.Apanel2.Visible = false;
            // 
            // btnPlanlekcji
            // 
            this.btnPlanlekcji.BackColor = System.Drawing.Color.Transparent;
            this.btnPlanlekcji.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPlanlekcji.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnPlanlekcji.FlatAppearance.BorderSize = 0;
            this.btnPlanlekcji.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnPlanlekcji.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnPlanlekcji.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlanlekcji.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlanlekcji.Location = new System.Drawing.Point(176, 11);
            this.btnPlanlekcji.Name = "btnPlanlekcji";
            this.btnPlanlekcji.Size = new System.Drawing.Size(102, 38);
            this.btnPlanlekcji.TabIndex = 28;
            this.btnPlanlekcji.Text = "Plan lekcji";
            this.btnPlanlekcji.UseVisualStyleBackColor = false;
            this.btnPlanlekcji.Click += new System.EventHandler(this.btnPlanlekcji_Click);
            // 
            // Apanel1
            // 
            this.Apanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(86)))), ((int)(((byte)(150)))));
            this.Apanel1.Location = new System.Drawing.Point(37, 43);
            this.Apanel1.Name = "Apanel1";
            this.Apanel1.Size = new System.Drawing.Size(102, 5);
            this.Apanel1.TabIndex = 27;
            this.Apanel1.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 69);
            this.panel4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(459, 388);
            this.panel4.TabIndex = 1;
            // 
            // uczenMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 457);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "uczenMain";
            this.Text = "uczenMain";
            this.Load += new System.EventHandler(this.uczenMain_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel Apanel2;
        private System.Windows.Forms.Button btnPlanlekcji;
        private System.Windows.Forms.Panel Apanel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnWyloguj;
    }
}