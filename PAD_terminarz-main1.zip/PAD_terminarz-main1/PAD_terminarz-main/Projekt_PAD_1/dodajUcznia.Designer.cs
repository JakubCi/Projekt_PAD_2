﻿namespace Projekt_PAD_1
{
    partial class dodajUcznia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dodajuczniaNazwisko = new System.Windows.Forms.TextBox();
            this.dodajuczniaImie = new System.Windows.Forms.TextBox();
            this.dodajuczniaPesel = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUtworz = new System.Windows.Forms.Button();
            this.btnCofnij = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // dodajuczniaNazwisko
            // 
            this.dodajuczniaNazwisko.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dodajuczniaNazwisko.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dodajuczniaNazwisko.ForeColor = System.Drawing.Color.Gray;
            this.dodajuczniaNazwisko.Location = new System.Drawing.Point(7, 111);
            this.dodajuczniaNazwisko.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.dodajuczniaNazwisko.Multiline = true;
            this.dodajuczniaNazwisko.Name = "dodajuczniaNazwisko";
            this.dodajuczniaNazwisko.PasswordChar = '*';
            this.dodajuczniaNazwisko.Size = new System.Drawing.Size(280, 30);
            this.dodajuczniaNazwisko.TabIndex = 17;
            this.dodajuczniaNazwisko.UseSystemPasswordChar = true;
            this.dodajuczniaNazwisko.TextChanged += new System.EventHandler(this.dodajuczniaNazwisko_TextChanged);
            // 
            // dodajuczniaImie
            // 
            this.dodajuczniaImie.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dodajuczniaImie.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dodajuczniaImie.ForeColor = System.Drawing.Color.Gray;
            this.dodajuczniaImie.Location = new System.Drawing.Point(7, 49);
            this.dodajuczniaImie.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.dodajuczniaImie.Multiline = true;
            this.dodajuczniaImie.Name = "dodajuczniaImie";
            this.dodajuczniaImie.Size = new System.Drawing.Size(280, 30);
            this.dodajuczniaImie.TabIndex = 16;
            this.dodajuczniaImie.TextChanged += new System.EventHandler(this.dodajuczniaImie_TextChanged);
            // 
            // dodajuczniaPesel
            // 
            this.dodajuczniaPesel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dodajuczniaPesel.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dodajuczniaPesel.ForeColor = System.Drawing.Color.Gray;
            this.dodajuczniaPesel.Location = new System.Drawing.Point(7, 179);
            this.dodajuczniaPesel.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.dodajuczniaPesel.Multiline = true;
            this.dodajuczniaPesel.Name = "dodajuczniaPesel";
            this.dodajuczniaPesel.Size = new System.Drawing.Size(280, 30);
            this.dodajuczniaPesel.TabIndex = 18;
            this.dodajuczniaPesel.TextChanged += new System.EventHandler(this.dodajuczniaPesel_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 16);
            this.label1.TabIndex = 20;
            this.label1.Text = "Imię";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 91);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 21;
            this.label2.Text = "Nazwisko";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 158);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 16);
            this.label3.TabIndex = 22;
            this.label3.Text = "Pesel";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(4, 221);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Klasa";
            // 
            // btnUtworz
            // 
            this.btnUtworz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(132)))), ((int)(((byte)(31)))));
            this.btnUtworz.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnUtworz.FlatAppearance.BorderSize = 0;
            this.btnUtworz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUtworz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnUtworz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUtworz.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUtworz.Location = new System.Drawing.Point(161, 326);
            this.btnUtworz.Name = "btnUtworz";
            this.btnUtworz.Size = new System.Drawing.Size(140, 38);
            this.btnUtworz.TabIndex = 24;
            this.btnUtworz.Text = "Utwórz";
            this.btnUtworz.UseVisualStyleBackColor = false;
            this.btnUtworz.Click += new System.EventHandler(this.btnUtworz_Click);
            // 
            // btnCofnij
            // 
            this.btnCofnij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(132)))), ((int)(((byte)(31)))));
            this.btnCofnij.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCofnij.FlatAppearance.BorderSize = 0;
            this.btnCofnij.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCofnij.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnCofnij.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCofnij.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCofnij.Location = new System.Drawing.Point(7, 326);
            this.btnCofnij.Name = "btnCofnij";
            this.btnCofnij.Size = new System.Drawing.Size(140, 38);
            this.btnCofnij.TabIndex = 25;
            this.btnCofnij.Text = "Cofnij";
            this.btnCofnij.UseVisualStyleBackColor = false;
            this.btnCofnij.Click += new System.EventHandler(this.btnCofnij_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(7, 240);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(280, 21);
            this.comboBox1.TabIndex = 26;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dodajUcznia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 375);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnCofnij);
            this.Controls.Add(this.btnUtworz);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dodajuczniaPesel);
            this.Controls.Add(this.dodajuczniaNazwisko);
            this.Controls.Add(this.dodajuczniaImie);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "dodajUcznia";
            this.Text = "dodajUcznia";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox dodajuczniaNazwisko;
        public System.Windows.Forms.TextBox dodajuczniaImie;
        public System.Windows.Forms.TextBox dodajuczniaPesel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnUtworz;
        private System.Windows.Forms.Button btnCofnij;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}